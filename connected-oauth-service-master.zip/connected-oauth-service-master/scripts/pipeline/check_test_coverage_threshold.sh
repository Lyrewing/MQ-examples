#!/bin/bash -e

# check_test_coverage_threshold.sh
# What does it do?
# It returns with 0 if the given LCOV report covers less than 100% of the code.
# Otherwise, it returns with 1.
#
# How to use:
# sh check_test_coverage_threshold.sh LCOV_REPORT_LOCATION
# where LCOV_REPORT_LOCATION is the location of your xxx.info file generated
# by LCOV.

LCOV_REPORT_LOCATION=$1

lcov --summary $LCOV_REPORT_LOCATION 2>&1 | awk '
  { if (index($2,"%") !=0)
    {
      if ((substr($2,1,length($2)-1)+0) < 100.0) {
        print "Test Coverage below threshold of 100.0. Retry. Coverage:"
        print $2
        exit 1
      }
      else {
        print "Test Coverage above threshold of 100.0. OK!"
        exit 0
      }
    }
  }'
exit $?