#!/bin/bash -e

curl -H "Content-Type: application/json" -X POST \
  https://outlook.office.com/webhook/409569be-268d-4a78-8d94-721fb706f3ad@ce849bab-cc1c-465b-b62e-18f07c9ac198/IncomingWebhook/da455ee3f3de4c6986ab389b59a456d7/cba3b7e0-c41e-4296-b0c5-c2737b1257f3 \
  -d '{"@context":"https:\/\/schema.org\/extensions","@type":"MessageCard","themeColor":"FF0000","title":"connected-oauth-service not deployed","text":"After 3 retries, could not deploy. Check with Runtime ASAP","potentialAction":[{"@type":"OpenUri","name":"Commit History Link","targets":[{"os":"default","uri":"https:\/\/code.connected.bmw\/mobile20\/connected-oauth-service\/commits\/master"}]}]}'
