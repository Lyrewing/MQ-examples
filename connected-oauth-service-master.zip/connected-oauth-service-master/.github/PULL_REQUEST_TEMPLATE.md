* **JIRA ticket link**: [JIRA ticket](http://suus0002.w10:8080/browse/MOB-) <<-- Add the link here
* **Team**: [Type the name of your team here]
* **Architecture link**: [Architecture proposal](https://pages.code.connected.bmw/mobile20/mobile-docs/docs/architecture/) <<-- Add the link here

### Description

Type your description here

##### Screenshots & GIFs

If your PR modifies any UI, please add screenshots here. (If you can resize them to be web friendly, kudos to you ;). 
If valuable, GIFs are also welcomed ([DropToGif might help you with that](https://github.com/mortenjust/droptogif))
Feel free to remove this section if the UI remains the same.
