import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as request from 'supertest';
import { AppModule } from '../../../../src/app.module';

describe('State (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/.internal/v1/state/user/usid (GET)', () => {
    return request(app.getHttpServer())
      .get('/.internal/v1/state/user/usid')
      .expect(404);
  });

  it('/.internal/v1/state/user/usid (DELETE)', () => {
    return request(app.getHttpServer())
      .delete('/.internal/v1/state/user/usid')
      .expect(404);
  });
});
