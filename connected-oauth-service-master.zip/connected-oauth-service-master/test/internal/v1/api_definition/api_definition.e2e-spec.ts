import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as request from 'supertest';
import { AppModule } from '../../../../src/app.module';
import { ApiDefinitionService } from '../../../../src/internal/v1/api_definition/api_definition.service';
import { ApiDefinitionController } from '../../../../src/internal/v1/api_definition/api_definition.controller';
import { Request, Response, NextFunction } from 'express';

describe('API Definition (e2e)', () => {
  let app: INestApplication;
  let apiDefinitionService: ApiDefinitionService;

  beforeAll(async () => {
    apiDefinitionService = new ApiDefinitionService();
    const moduleFixture = await Test.createTestingModule({
      controllers: [ApiDefinitionController],
      imports: [AppModule],
      providers: [
        { provide: ApiDefinitionService, useValue: apiDefinitionService },
      ],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.use((_: Request, res: any, next: NextFunction) => {
      const swagger = 'swagger';
      const document = { swagger: '2.0' };
      res.res = {};
      res.res.locals = res.res.locals
        ? (res.res.locals[swagger] = document)
        : { swagger: document };
      next();
    });
    await app.init();
  });

  it('/.internal/v1/api-definition/openapi3 (GET)', () => {
    spyOn(apiDefinitionService, 'getOpenApiDocumentation').and.returnValue(
      Promise.resolve('value'),
    );
    return request(app.getHttpServer())
      .get('/.internal/v1/api-definition/openapi3')
      .expect(200);
  });

  it('/.internal/v1/api-definition/openapi3 (GET)', () => {
    spyOn(apiDefinitionService, 'getOpenApiDocumentation').and.returnValue(
      Promise.resolve('value'),
    );
    return request(app.getHttpServer())
      .get('/.internal/v1/api-definition/openapi3')
      .set('x-jmespath', 'query')
      .expect(200);
  });

  it('/.internal/v1/api-definition/openapi3 (GET)', () => {
    spyOn(apiDefinitionService, 'getOpenApiDocumentation').and.throwError(
      'failure',
    );
    return request(app.getHttpServer())
      .get('/.internal/v1/api-definition/openapi3')
      .set('x-jmespat', 'query')
      .expect(500);
  });
});
