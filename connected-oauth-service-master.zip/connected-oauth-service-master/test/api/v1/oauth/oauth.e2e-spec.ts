import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as request from 'supertest';
import { OAuthController } from '../../../../src/api/v1/oauth/oauth.controller';
import { ConnectedOAuthService } from '../../../../src/api/v1/oauth/oauth.service';
import { MockOAuthService } from '../../../../src/api/v1/oauth/oauth.service.mock';
import { Token, TokenError } from '../../../../src/api/v1/oauth/models';
import { I18nService, I18nModule } from 'nestjs-i18n';
import { Locale } from '@bmw/nestjs';

describe('OAuth (e2e)', () => {
  let app: INestApplication;
  let oAuthService: MockOAuthService;
  let i18n: I18nService;
  const locale: Locale = new Locale('en', 'us');

  const validToken: Token = {
    access_token: 'access_token',
    refresh_token: 'refresh_token',
    expires_in: 100,
    token_type: 'token_type',
    usid: 'usid',
  };

  const validRefreshToken: Token = {
    access_token: 'access_token',
    refresh_token: 'refresh_token',
    expires_in: 100,
    token_type: 'token_type',
  };

  beforeAll(async () => {
    oAuthService = new MockOAuthService();
    const moduleFixture = await Test.createTestingModule({
      controllers: [OAuthController],
      providers: [{ provide: ConnectedOAuthService, useValue: oAuthService }],
      imports: [I18nModule.forRoot({ path: 'any', fallbackLanguage: 'US' })],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    i18n = moduleFixture.get(I18nService);
    spyOn(i18n, 'translate').and.returnValue('error');
  });

  it('/api/v1/oauth/token (POST) returns 400 for invalid grant_type', () => {
    return request(app.getHttpServer())
      .post('/api/v1/oauth/token')
      .send({
        grant_type: 'invalid_grant_type',
        username: 'username',
        password: 'password',
      })
      .set('accept-language', locale.toString())
      .expect(400);
  });

  it('/api/v1/oauth/token (POST) returns 400 for missing grant_type', () => {
    return request(app.getHttpServer())
      .post('/api/v1/oauth/token')
      .send({
        username: 'username',
        password: 'password',
      })
      .set('accept-language', locale.toString())
      .expect(400);
  });

  describe('grant_type password', () => {
    it('/api/v1/oauth/token (POST) returns 200', () => {
      oAuthService.tokenResponse = validToken;

      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'password',
          username: 'username',
          password: 'password',
        })
        .set('accept-language', locale.toString())
        .expect(200)
        .expect(validToken);
    });

    it('/api/v1/oauth/token (POST) returns 400 for missing username', () => {
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'password',
          password: 'password',
        })
        .set('accept-language', locale.toString())
        .expect(400);
    });

    it('/api/v1/oauth/token (POST) returns 400 for missing password', () => {
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'password',
          username: 'username',
        })
        .set('accept-language', locale.toString())
        .expect(400);
    });

    it('/api/v1/oauth/token (POST) returns 500 for token exception on login', () => {
      oAuthService.tokenError = new Error('token-error');
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'password',
          username: 'username',
          password: 'password',
        })
        .set('accept-language', locale.toString())
        .expect(400);
    });
  });

  describe('grant_type refresh_token', () => {
    it('/api/v1/oauth/token (POST) returns 200', () => {
      oAuthService.refreshTokenResponse = validRefreshToken;

      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'refresh_token',
          refresh_token: 'refresh-token',
        })
        .set('accept-language', locale.toString())
        .expect(200)
        .expect(validRefreshToken);
    });

    it('/api/v1/oauth/token (POST) returns 400 for missing refresh_token', () => {
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'refresh_token',
        })
        .set('accept-language', locale.toString())
        .expect(400);
    });

    it('/api/v1/oauth/token (POST) returns 401 for RefreshTokenFailedError', () => {
      oAuthService.refreshTokenError = TokenError.RefreshTokenFailed;
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'refresh_token',
          refresh_token: 'refresh-token',
        })
        .set('accept-language', locale.toString())
        .expect(401);
    });

    it('/api/v1/oauth/token (POST) returns 400 for refresh token exception', () => {
      oAuthService.refreshTokenError = TokenError.InvalidRequest;
      return request(app.getHttpServer())
        .post('/api/v1/oauth/token')
        .send({
          grant_type: 'refresh_token',
          refresh_token: 'refresh-token',
        })
        .set('accept-language', locale.toString())
        .expect(400);
    });
  });

  describe('revoke GCDM tokens', () => {
    it('/api/v1/oauth/token (DELETE) returns 204', () => {
      return request(app.getHttpServer())
        .delete('/api/v1/oauth/token')
        .set('authorization', 'Bearer abcdefghij')
        .set('x-refresh-token', 'klmnopqrstuv')
        .set('accept-language', locale.toString())
        .expect(204);
    });

    it('/api/v1/oauth/token (DELETE) returns 439 for missing GCDM Access Token', () => {
      return request(app.getHttpServer())
        .delete('/api/v1/oauth/token')
        .set('x-refresh-token', 'klmnopqrstuv')
        .set('accept-language', locale.toString())
        .expect(439);
    });

    it('/api/v1/oauth/token (DELETE) returns 439 for missing GCDM Access Token', () => {
      return request(app.getHttpServer())
        .delete('/api/v1/oauth/token')
        .set('authorization', 'Bearer abcdefghij')
        .set('accept-language', locale.toString())
        .expect(439);
    });

    it('/api/v1/oauth/token (DELETE) returns 440 for RevokeTokensFailedError thrown by service', () => {
      oAuthService.gcdmRevokeTokensError = TokenError.GcdmTokensRevokeFailed;
      return request(app.getHttpServer())
        .delete('/api/v1/oauth/token')
        .set('authorization', 'Bearer abcdefghij')
        .set('x-refresh-token', 'klmnopqrstuv')
        .set('accept-language', locale.toString())
        .expect(440);
    });
  });
});
