# btc-connected-oauth-service
## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Installation

You may need to do this without proxy, or you can create a rule for `http://btcnpmregistry.centralus.cloudapp.azure.com` to use **HTTP**. `*.azure.com` utilizes **HTTPS** by default, which always fails for npm.

```bash
# set location to BMW's npm registry
$ npm set registry http://btcnpmregistry.centralus.cloudapp.azure.com

# install dependencies
$ npm install
```

If that doesn't work, try these steps:

* Turn off Proxifier
* Switch to Innovations / WiFi hot-spot
* Go to **System Preferences**
* Switch your **Location** to something besides "BMW" that has Proxy disabled
  * For instance, if you have a "Home" environment with Proxy disabled

If you don't have a Location without a proxy:

* Select **Locations**, and click on **Edit Locations...** and duplicate your "BMW" Location
  * We want the other settings, just not the Proxy configuration
* Go to **Advanced...** settings in the bottom-right corner
* Select **Proxies** and un-check all of the boxes

## Running the app

In order to run the app locally please make sure the desired environment variables are configured in `env/local.env`.
For secrets please reach out to Felix Angelov or Nicholas Martin.

### Running Outside Docker

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# incremental rebuild (webpack)
$ npm run webpack
$ npm run start:hmr

# production mode
$ npm run start:prod
```

### Running Inside Docker

```bash
# production mode
$ npm run docker:start
```

## Test

### Testing Outside Docker

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

### Testing Inside Docker

```bash
# all tests w/coverage
$ npm run docker:test
```

## Swagger

```bash
# run server
$ npm run docker:start
```

* Generated Swagger documentation can be seen at http://localhost:8080/docs

* Comprehensive documentation about how to generate Swagger can be found [here](https://docs.nestjs.com/recipes/swagger).