import { Module } from '@nestjs/common';

import { InternalModule } from './internal/internal.module';
import { OAuthModule } from './api/v1/oauth/oauth.module';
import { I18nModule } from 'nestjs-i18n';
import { config } from './config';

@Module({
  imports: [
    InternalModule,
    OAuthModule,
    I18nModule.forRoot({
      path: config.localizationsDirectory,
      filePattern: config.localizationsFilePattern,
      fallbackLanguage: config.localizationsFallbackLanguage,
    }),
  ],
})
export class AppModule {}
