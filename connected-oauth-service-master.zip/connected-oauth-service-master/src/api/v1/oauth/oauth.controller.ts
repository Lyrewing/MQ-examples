import * as _ from 'lodash';

import {
  Body,
  Controller,
  HttpException,
  HttpCode,
  Post,
  Delete,
  Headers,
} from '@nestjs/common';

import {
  getAccessToken,
  AcceptLanguagePipe,
  Locale,
  RequestHeader,
} from '@bmw/nestjs';

import {
  ApiUseTags,
  ApiOperation,
  ApiResponse,
  ApiImplicitHeader,
} from '@nestjs/swagger';

import { ConnectedOAuthService } from './oauth.service';
import {
  Authorization,
  Token,
  GrantType,
  TokenErrorResponse,
  TokenError,
} from './models';
import { I18nService } from 'nestjs-i18n';
import { HttpStatusCode } from '@bmw/http';

@ApiUseTags('Token')
@Controller('api/v1/oauth/token')
export class OAuthController {
  constructor(
    private readonly oAuthService: ConnectedOAuthService,
    private i18n: I18nService,
  ) {}

  @ApiOperation({
    title: 'Manage Token',
    description: 'request and refresh an access token',
  })
  @ApiImplicitHeader({
    name: 'accept-language',
    description: 'Accept Language',
    required: true,
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Token,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: TokenErrorResponse,
  })
  @ApiResponse({ status: 500, description: 'Internal Server Error' })
  @HttpCode(200)
  @Post()
  async post(
    @Body() model: Authorization,
    @RequestHeader('accept-language', new AcceptLanguagePipe()) locale: Locale,
  ): Promise<Token> {
    const grantType: string = _.get(model, 'grant_type');

    if (
      grantType !== GrantType.Password &&
      grantType !== GrantType.RefreshToken
    ) {
      const error = TokenError.InvalidRequest;
      throw new HttpException(
        new TokenErrorResponse(error, this.getMessage(error, locale)),
        HttpStatusCode.BadRequest,
      );
    }

    if (grantType === GrantType.Password) {
      if (_.isNil(model.username) || _.isNil(model.password)) {
        const error = TokenError.InvalidRequest;
        throw new HttpException(
          new TokenErrorResponse(error, this.getMessage(error, locale)),
          HttpStatusCode.BadRequest,
        );
      }
      try {
        return await this.oAuthService.getToken(model.username, model.password);
      } catch (error) {
        throw new HttpException(
          new TokenErrorResponse(error, this.getMessage(error, locale)),
          HttpStatusCode.BadRequest,
        );
      }
    } else {
      if (_.isNil(model.refresh_token)) {
        const error = TokenError.InvalidRequest;
        throw new HttpException(
          new TokenErrorResponse(error, this.getMessage(error, locale)),
          HttpStatusCode.BadRequest,
        );
      }
      try {
        return await this.oAuthService.refreshToken(model.refresh_token);
      } catch (error) {
        const response = new TokenErrorResponse(
          error,
          this.getMessage(error, locale),
        );
        throw error === TokenError.RefreshTokenFailed
          ? new HttpException(response, HttpStatusCode.Unauthorized)
          : new HttpException(response, HttpStatusCode.BadRequest);
      }
    }
  }

  @ApiOperation({
    title: 'Revoke Token',
    description: 'Revoke GCDM access and refresh tokens',
  })
  @ApiImplicitHeader({
    name: 'accept-language',
    description: 'Accept Language',
    required: true,
  })
  @ApiResponse({
    status: 204,
    description: 'No Content',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: TokenErrorResponse,
  })
  @ApiResponse({ status: 424, description: 'Failed Dependency' })
  @ApiResponse({
    status: 439,
    description: 'GCDM Tokens Invalid',
    type: TokenErrorResponse,
  })
  @ApiResponse({
    status: 440,
    description: 'Revoke Token Error',
    type: TokenErrorResponse,
  })
  @ApiResponse({
    status: 500,
    description: 'Internal Server Error',
    type: TokenErrorResponse,
  })
  @HttpCode(204)
  @Delete()
  async delete(
    @Headers('authorization') authorization: string,
    @Headers('x-refresh-token') refreshToken: string,
    @RequestHeader('accept-language', new AcceptLanguagePipe()) locale: Locale,
  ): Promise<void> {
    if (_.isNil(authorization) || _.isNil(refreshToken)) {
      const error = TokenError.InvalidRequest;
      throw new HttpException(
        new TokenErrorResponse(error, this.getMessage(error, locale)),
        439,
      );
    }

    try {
      const gcdmAccessToken = getAccessToken(authorization);
      const gcdmRefreshToken = refreshToken;

      await this.oAuthService.revokeTokens(gcdmAccessToken, gcdmRefreshToken);
    } catch (error) {
      throw new HttpException(
        new TokenErrorResponse(error, this.getMessage(error, locale)),
        440,
      );
    }
  }

  private getMessage(messageKey: string, locale: Locale): string {
    return this.i18n.translate(
      `${locale.language}_${locale.region.toLocaleUpperCase()}`,
      messageKey,
    );
  }
}
