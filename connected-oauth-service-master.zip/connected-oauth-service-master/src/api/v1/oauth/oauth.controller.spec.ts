import { Test } from '@nestjs/testing';
import { OAuthController } from './oauth.controller';
import { ConnectedOAuthService } from './oauth.service';
import { MockOAuthService } from './oauth.service.mock';
import { Token, GrantType, TokenError } from './models';
import { HttpException } from '@nestjs/common';
import { Locale } from '@bmw/nestjs';
import { I18nModule, I18nService } from 'nestjs-i18n';

describe('OAuthController', () => {
  let oAuthController: OAuthController;
  let oAuthService: MockOAuthService;
  const locale: Locale = new Locale('en', 'us');
  let i18n: I18nService;

  beforeEach(async () => {
    oAuthService = new MockOAuthService();
    const module = await Test.createTestingModule({
      controllers: [OAuthController],
      providers: [{ provide: ConnectedOAuthService, useValue: oAuthService }],
      imports: [I18nModule.forRoot({ path: 'any', fallbackLanguage: 'US' })],
    }).compile();

    i18n = module.get(I18nService);
    oAuthController = module.get<OAuthController>(OAuthController);
    spyOn(i18n, 'translate').and.returnValue('error');
  });

  describe('post', () => {
    it('should return bad request on missing grant_type', async () => {
      try {
        await oAuthController.post(
          {
            username: 'username',
            password: 'password',
            grant_type: undefined,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });

    it('should return bad request on invalid grant_type', async () => {
      try {
        await oAuthController.post(
          {
            username: 'username',
            password: 'password',
            grant_type: 'invalid_grant_type',
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });
  });

  describe('post (grant_type: password)', () => {
    it('should return token on success', async () => {
      try {
        const expectedToken: Token = {
          access_token: 'access_token',
          refresh_token: 'refresh_token',
          expires_in: 100,
          token_type: 'token_type',
          usid: 'usid',
        };
        oAuthService.tokenResponse = expectedToken;
        const token = await oAuthController.post(
          {
            username: 'username',
            password: 'password',
            grant_type: GrantType.Password,
          },
          locale,
        );
        expect(token).toEqual(expectedToken);
      } catch (error) {
        fail(error);
      }
    });

    it('should return error on exception', async () => {
      try {
        oAuthService.tokenError = new Error('token error');
        await oAuthController.post(
          {
            username: 'username',
            password: 'password',
            grant_type: GrantType.Password,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });

    it('should return bad request on missing username', async () => {
      try {
        await oAuthController.post(
          {
            username: undefined,
            password: 'password',
            grant_type: GrantType.Password,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });

    it('should return bad request on missing password', async () => {
      try {
        await oAuthController.post(
          {
            username: 'username',
            password: undefined,
            grant_type: GrantType.Password,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });

    it('should return bad request on missing username and password', async () => {
      try {
        await oAuthController.post(
          {
            username: undefined,
            password: undefined,
            grant_type: GrantType.Password,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });
  });

  describe('post (grant_type: refresh_token)', () => {
    it('should return token on success', async () => {
      try {
        const expectedToken: Token = {
          access_token: 'access_token',
          refresh_token: 'refresh_token',
          expires_in: 100,
          token_type: 'token_type',
        };
        oAuthService.refreshTokenResponse = expectedToken;
        const token = await oAuthController.post(
          {
            refresh_token: 'refresh-token',
            grant_type: GrantType.RefreshToken,
          },
          locale,
        );
        expect(token).toEqual(expectedToken);
      } catch (error) {
        fail(error);
      }
    });

    it('should return HttpException 401 when service throws a RefreshTokenFailedError', async () => {
      try {
        oAuthService.refreshTokenError = TokenError.RefreshTokenFailed;
        await oAuthController.post(
          {
            refresh_token: 'refresh-token',
            grant_type: GrantType.RefreshToken,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(401);
      }
    });

    it('should return HttpException 400 when service throws IncorrectTokenFailedError', async () => {
      try {
        oAuthService.refreshTokenError = TokenError.InvalidRequest;
        await oAuthController.post(
          {
            refresh_token: 'refresh-token',
            grant_type: GrantType.RefreshToken,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });

    it('should return bad request on missing refresh_token', async () => {
      try {
        await oAuthController.post(
          {
            grant_type: GrantType.RefreshToken,
          },
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(400);
      }
    });
  });

  describe('delete token', () => {
    const mockGCDMAccessToken = 'mockAccessToken';
    const mockGCDMRefreshToken = 'mockRefreshToken';
    it('should return undefined on success', async () => {
      try {
        const result = await oAuthController.delete(
          mockGCDMAccessToken,
          mockGCDMRefreshToken,
          locale,
        );
        expect(result).toBeUndefined();
      } catch (error) {
        fail(error);
      }
    });

    it('should return HTTP 439 if GCDMAccessToken is null', async () => {
      try {
        await oAuthController.delete(null, mockGCDMRefreshToken, locale);
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(439);
      }
    });

    it('should return HTTP 439 if GCDMRefreshToken is null', async () => {
      try {
        await oAuthController.delete(mockGCDMAccessToken, null, locale);
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(439);
      }
    });

    it('should return HTTP 440 if exception is returned by FG Revoke', async () => {
      oAuthService.gcdmRevokeTokensError = new Error('Mock FG Revoke Error');
      try {
        await oAuthController.delete(
          mockGCDMAccessToken,
          mockGCDMRefreshToken,
          locale,
        );
        fail('should throw exception');
      } catch (error) {
        expect((error as HttpException).getStatus()).toEqual(440);
      }
    });
  });
});
