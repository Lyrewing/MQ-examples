import 'reflect-metadata';
import { TokenError } from '../models';
import {
  mapErrorToGetTokenErrorMessage,
  mapErrorToRefreshTokenErrorMessage,
} from '.';
import { GCDMTokenError } from '@bmw/token-api';
import { HttpError } from '@bmw/http';

describe('mapErrorToGetTokenErrorMessage', () => {
  it('returns unconfirmedAccount error on GCDMTokenError.AccountNotActivatedAppException', () => {
    expect(
      mapErrorToGetTokenErrorMessage(
        GCDMTokenError.AccountNotActivatedAppException,
      ),
    ).toEqual(TokenError.UnconfirmedAccount);
  });

  it('returns accountLocked error on GCDMTokenError.AccountLockedAppException', () => {
    expect(
      mapErrorToGetTokenErrorMessage(GCDMTokenError.AccountLockedAppException),
    ).toEqual(TokenError.AccountLocked);
  });

  it('returns incorrectAccountInformation error on GCDMTokenError.AuthenticationFailedAppException', () => {
    expect(
      mapErrorToGetTokenErrorMessage(
        GCDMTokenError.AuthenticationFailedAppException,
      ),
    ).toEqual(TokenError.IncorrectAccountInformation);
  });

  it('returns incorrectAccountInformation error on GCDMTokenError.ValidationAppException', () => {
    expect(
      mapErrorToGetTokenErrorMessage(GCDMTokenError.ValidationAppException),
    ).toEqual(TokenError.IncorrectAccountInformation);
  });

  it('returns incorrectAccountInformation error on GCDMTokenError.NotFoundAppException', () => {
    expect(
      mapErrorToGetTokenErrorMessage(GCDMTokenError.NotFoundAppException),
    ).toEqual(TokenError.IncorrectAccountInformation);
  });

  it('returns gcdmTokensRequestFailed error on undefined', () => {
    expect(mapErrorToGetTokenErrorMessage(undefined)).toEqual(
      TokenError.GcdmTokensRequestFailed,
    );
  });
});

describe('mapErrorToRefreshTokenErrorMessage', () => {
  it('returns refreshTokenFailed error on 401', () => {
    expect(
      mapErrorToRefreshTokenErrorMessage(new HttpError('unauthorized', 401)),
    ).toEqual(TokenError.RefreshTokenFailed);
  });

  it('returns refreshTokenFailed error on undefined', () => {
    expect(mapErrorToRefreshTokenErrorMessage(undefined)).toEqual(
      TokenError.IncorrectAccountInformation,
    );
  });
});
