import { TokenError } from '../models';
import * as _ from 'lodash';
import { HttpError } from '@bmw/http';
import { GCDMTokenError } from '@bmw/token-api';

export function mapErrorToGetTokenErrorMessage(error: any): TokenError {
  switch (error) {
    case GCDMTokenError.AccountNotActivatedAppException:
      return TokenError.UnconfirmedAccount;
    case GCDMTokenError.AccountLockedAppException:
      return TokenError.AccountLocked;
    case GCDMTokenError.AuthenticationFailedAppException:
    case GCDMTokenError.ValidationAppException:
    case GCDMTokenError.NotFoundAppException:
      return TokenError.IncorrectAccountInformation;
    default:
      return TokenError.GcdmTokensRequestFailed;
  }
}

export function mapErrorToRefreshTokenErrorMessage(error: Error) {
  return error instanceof HttpError && error.statusCode === 401
    ? TokenError.RefreshTokenFailed
    : TokenError.IncorrectAccountInformation;
}
