import { OAuthService, Token, TokenError } from './models';

export class MockOAuthService implements OAuthService {
  tokenError: any;
  refreshTokenError: any;
  tokenResponse: Token;
  refreshTokenResponse: Token;
  gcdmRevokeTokensError: any;

  getToken(_: string, __: string): Promise<Token> {
    return this.tokenError
      ? Promise.reject(this.tokenError)
      : Promise.resolve(this.tokenResponse);
  }

  refreshToken(_: string): Promise<Token> {
    return this.refreshTokenError
      ? Promise.reject(this.refreshTokenError)
      : Promise.resolve(this.refreshTokenResponse);
  }

  revokeTokens(
    gcdmAccessToken: string,
    gcdmRefreshToken: string,
  ): Promise<void> {
    return this.gcdmRevokeTokensError
      ? Promise.reject(this.gcdmRevokeTokensError)
      : Promise.resolve();
  }
}
