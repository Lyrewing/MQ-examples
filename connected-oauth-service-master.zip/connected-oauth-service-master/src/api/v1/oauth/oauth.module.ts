import { Module } from '@nestjs/common';
import { BMWTokenApiClient } from '@bmw/token-api';
import { BMWHttpClient } from '@bmw/http';
import { config } from '../../../config';

import { OAuthController } from './oauth.controller';
import { ConnectedOAuthService } from './oauth.service';

@Module({
  controllers: [OAuthController],
  providers: [
    {
      provide: BMWHttpClient,
      useValue: new BMWHttpClient({
        'x-cluster-caller': 'connected-oauth-service',
      }),
    },

    {
      provide: BMWTokenApiClient,
      useFactory: (httpClient: BMWHttpClient) => {
        return new BMWTokenApiClient(
          {
            loginBaseUrl: config.gcdmBaseUrl,
            gatewayBaseUrl: config.omcBaseUrl,
            loginBasicAuthToken: config.loginBasicAuthToken,
            gatewayBasicAuthToken: config.gatewayBasicAuthToken,
          },
          httpClient,
        );
      },
      inject: [BMWHttpClient],
    },
    ConnectedOAuthService,
  ],
})
export class OAuthModule {}
