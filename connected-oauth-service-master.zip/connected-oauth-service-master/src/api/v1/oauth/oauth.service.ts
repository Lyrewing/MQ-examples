import * as _ from 'lodash';
import { BMWTokenApiClient, TokenWrapper } from '@bmw/token-api';
import { Injectable } from '@nestjs/common';

import { OAuthService, Token, TokenError } from './models';
import { Logger } from '@bmw/nestjs';
import {
  mapErrorToRefreshTokenErrorMessage,
  mapErrorToGetTokenErrorMessage,
} from './utils';

@Injectable()
export class ConnectedOAuthService implements OAuthService {
  constructor(private tokenApiClient: BMWTokenApiClient) {}

  async getToken(username: string, password: string): Promise<Token> {
    let tokenWrapper: TokenWrapper;

    try {
      tokenWrapper = await this.tokenApiClient.getTokenWrapper({
        username,
        password,
      });
    } catch (error) {
      Logger.logError('failed_getting_token', error);
      throw mapErrorToGetTokenErrorMessage(error);
    }

    return {
      access_token: _.get(tokenWrapper, 'gatewayTokenResponse.access_token'),
      refresh_token: _.get(tokenWrapper, 'gatewayTokenResponse.refresh_token'),
      expires_in: parseInt(
        _.get(tokenWrapper, 'gatewayTokenResponse.expires_in'),
        10,
      ),
      token_type: _.get(tokenWrapper, 'gatewayTokenResponse.token_type'),
      usid: _.get(tokenWrapper, 'gatewayTokenResponse.usid'),
    };
  }

  async refreshToken(refreshToken: string): Promise<Token> {
    try {
      const token = await this.tokenApiClient.refreshGatewayToken(refreshToken);
      return {
        access_token: token.access_token,
        refresh_token: token.refresh_token,
        expires_in: Number(token.expires_in),
        token_type: token.token_type,
      };
    } catch (error) {
      Logger.logError('failed_refreshing_token', error);
      throw mapErrorToRefreshTokenErrorMessage(error);
    }
  }

  async revokeTokens(
    gcdmAccessToken: string,
    gcdmRefreshToken: string,
  ): Promise<void> {
    if (_.isNil(gcdmAccessToken) || _.isNil(gcdmRefreshToken)) {
      throw TokenError.GcdmTokenInvalid;
    }

    try {
      await this.tokenApiClient.revokeGCDMTokens(
        gcdmAccessToken,
        gcdmRefreshToken,
      );
    } catch (error) {
      Logger.logError('failed_refreshing_token', error);
      throw TokenError.GcdmTokensRevokeFailed;
    }
  }
}
