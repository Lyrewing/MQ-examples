import { Test } from '@nestjs/testing';
import { Logger } from '@bmw/nestjs';
import {
  BMWTokenApiClient,
  MockTokenApiClient,
  GCDMTokenError,
} from '@bmw/token-api';
import { HttpError } from '@bmw/http';

import { ConnectedOAuthService } from './oauth.service';
import { Token, TokenError } from './models';
import { I18nModule } from 'nestjs-i18n';

describe('ConnectedOAuthService', () => {
  let oauthService: ConnectedOAuthService;
  let tokenApiClient: MockTokenApiClient;

  beforeEach(async () => {
    spyOn(Logger, 'logError').and.returnValue(undefined);
    tokenApiClient = new MockTokenApiClient();
    const module = await Test.createTestingModule({
      providers: [
        { provide: BMWTokenApiClient, useValue: tokenApiClient },
        ConnectedOAuthService,
      ],
      imports: [I18nModule.forRoot({ path: 'any', fallbackLanguage: 'US' })],
    }).compile();

    oauthService = module.get<ConnectedOAuthService>(ConnectedOAuthService);
  });

  describe('getToken', () => {
    it('should return tokens when tokenApi returns a success', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.resolve({
          gcdmTokenResponse: undefined,
          gatewayTokenResponse: {
            access_token: 'access_token',
            refresh_token: 'refresh_token',
            token_type: 'token_type',
            expires_in: '100',
            usid: 'usid',
          },
        }),
      );
      const expectedToken: Token = {
        access_token: 'access_token',
        refresh_token: 'refresh_token',
        expires_in: 100,
        token_type: 'token_type',
        usid: 'usid',
      };
      try {
        const token = await oauthService.getToken('username', 'password');
        expect(token).toEqual(expectedToken);
        expect(tokenApiClient.getTokenWrapper).toBeCalledWith({
          username: 'username',
          password: 'password',
        });
      } catch (error) {
        fail(error);
      }
    });

    it('should throw 434 AccountLocked when tokenApi returns an AccountLockedAppException error', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.reject(GCDMTokenError.AccountLockedAppException),
      );
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.AccountLocked);
      }
    });

    it('should throw 432 UnconfirmedAccount when tokenApi returns an AccountNotActivatedAppException error', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.reject(GCDMTokenError.AccountNotActivatedAppException),
      );
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.UnconfirmedAccount);
      }
    });

    it('should throw 436 IncorrectAccountInformation when tokenApi returns an NotFoundAppException error', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.reject(GCDMTokenError.NotFoundAppException),
      );
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.IncorrectAccountInformation);
      }
    });

    it('should throw 433 IncorrectAccountInformation when tokenApi returns an AuthenticationFailedAppException error', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.reject(GCDMTokenError.AuthenticationFailedAppException),
      );
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.IncorrectAccountInformation);
      }
    });

    it('should throw 435 IncorrectAccountInformation when tokenApi returns an ValidationAppException error', async () => {
      spyOn(tokenApiClient, 'getTokenWrapper').and.returnValue(
        Promise.reject(GCDMTokenError.ValidationAppException),
      );
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.IncorrectAccountInformation);
      }
    });

    it('should throw GcdmTokensRequestFailed when tokenApi returns an unrecognized error', async () => {
      tokenApiClient.getTokenWrapperError = new Error('token-error');
      try {
        await oauthService.getToken('username', 'password');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.GcdmTokensRequestFailed);
      }
    });
  });

  describe('refreshToken', () => {
    it('should return token when token-api returns a success', async () => {
      tokenApiClient.refreshGatewayTokenResponse = {
        access_token: 'access_token',
        refresh_token: 'refresh_token',
        token_type: 'token_type',
        expires_in: '100',
        usid: undefined,
      };
      const expectedToken: Token = {
        access_token: 'access_token',
        refresh_token: 'refresh_token',
        expires_in: 100,
        token_type: 'token_type',
      };
      try {
        const token = await oauthService.refreshToken('mock-refresh-token');
        expect(token).toEqual(expectedToken);
      } catch (error) {
        fail(error);
      }
    });

    it('should throw RefreshTokenFailedError on 401 from token-api', async () => {
      tokenApiClient.refreshGatewayTokenError = new HttpError(
        'token-error',
        401,
      );
      try {
        await oauthService.refreshToken('mock-refresh-token');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.RefreshTokenFailed);
      }
    });

    it('should throw IncorrectTokenFailedError on 503 from token-api', async () => {
      tokenApiClient.refreshGatewayTokenError = new HttpError(
        'token-error',
        503,
      );
      try {
        await oauthService.refreshToken('mock-refresh-token');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.IncorrectAccountInformation);
      }
    });

    it('should throw IncorrectAccountInformation on other exceptions', async () => {
      tokenApiClient.refreshGatewayTokenError = new Error('exception');
      try {
        await oauthService.refreshToken('mock-refresh-token');
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.IncorrectAccountInformation);
      }
    });
  });
  describe('revokeToken', () => {
    const mockGCDMAccessToken = 'mockAccessToken';
    const mockGCDMRefreshToken = 'mockRefreshToken';
    it('should return undefined on success', async () => {
      try {
        const result = await oauthService.revokeTokens(
          mockGCDMAccessToken,
          mockGCDMRefreshToken,
        );
        expect(result).toBeUndefined();
      } catch (error) {
        fail(error);
      }
    });

    it('should return HTTP GcdmTokenInvalid if GCDMAccessToken is null', async () => {
      try {
        await oauthService.revokeTokens(null, mockGCDMRefreshToken);
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.GcdmTokenInvalid);
      }
    });

    it('should return HTTP GcdmTokenInvalid if GCDMRefreshToken is null', async () => {
      try {
        await oauthService.revokeTokens(mockGCDMAccessToken, null);
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.GcdmTokenInvalid);
      }
    });

    it('should return GcdmTokensRevokeFailed if exception is returned by FG Revoke', async () => {
      tokenApiClient.revokeGCDMTokensError = new Error('Mock FG Error');
      try {
        await oauthService.revokeTokens(
          mockGCDMAccessToken,
          mockGCDMRefreshToken,
        );
        fail('should throw exception');
      } catch (error) {
        expect(error).toEqual(TokenError.GcdmTokensRevokeFailed);
      }
    });
  });
});
