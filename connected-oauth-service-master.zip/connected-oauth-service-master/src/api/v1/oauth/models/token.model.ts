import { ApiModelProperty, ApiModelPropertyOptional } from '@nestjs/swagger';

export class Token {
  @ApiModelProperty({
    example: 'SlAV32hkKG',
    description:
      'secret which is used when making http requests to the OMC in order to authenticate',
  })
  /* tslint:disable-next-line:variable-name */
  readonly access_token: string;
  @ApiModelProperty({
    example: 'Bearer',
    description:
      'prefix for the Authorization header (eg: Authorization: Bearer {token}',
  })
  /* tslint:disable-next-line:variable-name */
  readonly token_type: string;
  @ApiModelProperty({
    example: '8xLOxBtZp8',
    description:
      'secret which is used when the access_token has expired in order to request a new access_token',
  })
  /* tslint:disable-next-line:variable-name */
  readonly refresh_token: string;
  @ApiModelProperty({
    example: 3600,
    description:
      'time (in seconds) for which the access_token is valid. After this all http requests which require a valid access_token will return a 401',
  })
  /* tslint:disable-next-line:variable-name */
  readonly expires_in: number;
  @ApiModelPropertyOptional({
    example: 'bdc5aa57-94bf-4c99-853a-f43ba2fda70a',
    description: 'unique user identifier only returned on a token request',
  })
  readonly usid?: string;
}
