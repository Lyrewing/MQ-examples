import { ApiModelProperty, ApiModelPropertyOptional } from '@nestjs/swagger';

export enum GrantType {
  Password = 'password',
  RefreshToken = 'refresh_token',
}

export class Authorization {
  @ApiModelProperty({
    enum: ['password', 'refresh_token'],
    example: 'password',
  })
  /* tslint:disable-next-line:variable-name */
  readonly grant_type: GrantType | string;
  @ApiModelPropertyOptional({ example: 'joe' })
  readonly username?: string;
  @ApiModelPropertyOptional({ example: 't0pS3cr3t' })
  readonly password?: string;
  @ApiModelPropertyOptional({
    example: 'E7N-ZB-3CYOsvkchYhdt1GRehx_1nBKSRQFFMmLB8w8r',
  })
  /* tslint:disable-next-line:variable-name */
  readonly refresh_token?: string;
}
