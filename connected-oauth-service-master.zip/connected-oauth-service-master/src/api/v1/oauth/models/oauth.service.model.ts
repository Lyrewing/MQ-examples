import { Token } from '.';
import { Locale } from '@bmw/nestjs';

export interface OAuthService {
  getToken: (username: string, password: string) => Promise<Token>;
  refreshToken: (refreshToken: string, locale: Locale) => Promise<Token>;
}
