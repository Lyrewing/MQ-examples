import { ApiModelProperty } from '@nestjs/swagger';

export enum TokenError {
  UnconfirmedAccount = 'unconfirmed_account',
  AccountLocked = 'account_locked',
  IncorrectAccountInformation = 'incorrect_account_information',
  RefreshTokenFailed = 'refresh_token_failed',
  GcdmTokenInvalid = 'gcdm_token_invalid',
  GcdmTokensRevokeFailed = 'gcdm_tokens_revoke_failed',
  InvalidRequest = 'invalid_request',
  GcdmTokensRequestFailed = 'gcdm_tokens_request_failed',
}

export class TokenErrorResponse {
  @ApiModelProperty({
    example: 'account_locked',
    enum: [
      'unconfirmed_account',
      'account_locked',
      'incorrect_account_information',
      'refresh_token_failed',
      'gcdm_token_invalid',
      'gcdm_tokens_revoke_failed',
      'invalid_request',
      'gcdm_tokens_request_failed',
    ],
  })
  readonly error;
  @ApiModelProperty({
    example: 'This account is locked please reset your password',
  })
  readonly description;

  constructor(error: TokenError, description: string) {
    this.error = error;
    this.description = description;
  }
}
