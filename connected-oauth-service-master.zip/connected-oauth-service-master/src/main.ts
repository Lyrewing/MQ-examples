import { NestFactory, FastifyAdapter } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { requestLogger, Logger } from '@bmw/nestjs';
import { AppModule } from './app.module';
import { config } from './config';
import { Request, Response, NextFunction } from 'express';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, new FastifyAdapter());

  Logger.build('connected-oauth-service');
  app.use(requestLogger());

  const options = new DocumentBuilder()
    .setTitle('connected-oauth-service')
    .setDescription('connected-oauth-service description')
    .setVersion('1.0')
    .build();

  const document = SwaggerModule.createDocument(app, options);
  app.use((_: Request, res: Response, next: NextFunction) => {
    const swagger = 'swagger';
    res.locals = res.locals
      ? (res.locals[swagger] = document)
      : { swagger: document };
    next();
  });
  SwaggerModule.setup('docs', app, document);

  await app.listen(config.port, '0.0.0.0');
}
bootstrap();
