import { Test, TestingModule } from '@nestjs/testing';
import { HealthController } from './health.controller';

describe('HealthController', () => {
  let app: TestingModule;

  beforeAll(async () => {
    app = await Test.createTestingModule({
      controllers: [HealthController],
    }).compile();
  });

  describe('/self', () => {
    it('should return with no exception', () => {
      const healthController = app.get<HealthController>(HealthController);
      expect(healthController.getSelfHealth).not.toThrow();
      expect(healthController.getSelfHealth()).toBeUndefined();
    });
  });

  describe('/upstreams', () => {
    it('should return OK', () => {
      const healthController = app.get<HealthController>(HealthController);
      expect(healthController.getUpstreamsHealth()).toEqual('OK');
    });
  });
});
