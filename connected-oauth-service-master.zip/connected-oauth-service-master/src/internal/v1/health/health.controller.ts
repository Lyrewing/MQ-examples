import { Controller, Get, HttpCode } from '@nestjs/common';
import { ApiUseTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

@ApiUseTags('Health')
@Controller('.internal/v1/health')
export class HealthController {
  @ApiOperation({ title: 'Check if HTTP Webserver is running' })
  @ApiResponse({ status: 201, description: 'Success' })
  @ApiResponse({ status: 500, description: 'Internal Server Error' })
  @ApiResponse({ status: 501, description: 'Not Implemented' })
  @Get('self')
  @HttpCode(201)
  getSelfHealth(): void {
    return;
  }

  @ApiOperation({
    title:
      'Check if HTTP Webserver is running and, when possible, database (and other TCP tunnels) are in a good state',
  })
  @ApiResponse({ status: 200, description: 'Success' })
  @ApiResponse({ status: 500, description: 'Internal Server Error' })
  @ApiResponse({ status: 501, description: 'Not Implemented' })
  @Get('upstreams')
  getUpstreamsHealth(): string {
    return 'OK';
  }
}
