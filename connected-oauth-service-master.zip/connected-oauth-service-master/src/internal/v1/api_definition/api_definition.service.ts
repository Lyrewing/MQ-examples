import * as jmespath from 'jmespath';
import * as Converter from 'api-spec-converter';
export class ApiDefinitionService {
  async getOpenApiDocumentation(
    swagger: any,
    jmesQuery: string,
  ): Promise<object> {
    const openApi3 = await Converter.convert({
      from: 'swagger_2',
      to: 'openapi_3',
      source: swagger,
    }).then(converted => {
      return JSON.parse(converted.stringify());
    });
    const content = jmesQuery ? jmespath.search(openApi3, jmesQuery) : openApi3;
    return content;
  }
}
