import { Test } from '@nestjs/testing';
import { ApiDefinitionService } from './api_definition.service';
import { ApiDefinitionController } from './api_definition.controller';
import { HttpException } from '@nestjs/common';

describe('ApiDefinitionController', () => {
  let controller: ApiDefinitionController;
  let apiDefinionService: ApiDefinitionService;

  beforeEach(async () => {
    apiDefinionService = new ApiDefinitionService();
    const module = await Test.createTestingModule({
      controllers: [ApiDefinitionController],
      providers: [
        { provide: ApiDefinitionService, useValue: apiDefinionService },
      ],
    }).compile();
    controller = module.get<ApiDefinitionController>(ApiDefinitionController);
  });

  describe('getOpenApiDocumentation', () => {
    it('should return the documentation on success', async () => {
      try {
        const response = {
          res: { locals: { swagger: { swagger: '2.0' } } },
          send: () => undefined,
        };
        spyOn(apiDefinionService, 'getOpenApiDocumentation').and.returnValue(
          Promise.resolve({ swagger: '2.0' }),
        );
        const documentation = await controller.getOpenApiDocumentation(
          '',
          response,
        );
        expect(documentation).toEqual({ swagger: '2.0' });
      } catch (error) {
        fail(error);
      }
    });

    it('should return internal server error on exception', async () => {
      try {
        const response = {
          res: { locals: { swagger: { swagger: '2.0' } } },
          send: () => undefined,
        };
        spyOn(apiDefinionService, 'getOpenApiDocumentation').and.throwError(
          'api error',
        );
        await controller.getOpenApiDocumentation('', response);
        fail('it should throw');
      } catch (error) {
        expect(error instanceof HttpException).toEqual(true);
        expect((error as HttpException).getStatus()).toEqual(500);
      }
    });
  });
});
