import { ApiDefinitionService } from './api_definition.service';

describe('ApiDefintionService', () => {
  const swagger2TestContent = {
    swagger: '2.0',
    info: {
      description: 'btc-user-composite-service description',
      version: '1.0',
      title: 'btc-user-composite-service',
    },
    basePath: '/',
    tags: [],
    schemes: ['http'],
    paths: {},
    definitions: {},
  };
  const openapi = 'openapi';
  let service: ApiDefinitionService;

  beforeEach(async () => {
    service = new ApiDefinitionService();
  });

  describe('getOpenApiDocumentation', () => {
    it('should return the openapi document if jmes query is null', async () => {
      const result = await service.getOpenApiDocumentation(
        swagger2TestContent,
        null,
      );
      const swaggerVersion = result[openapi];
      expect(result).not.toEqual(swagger2TestContent);
      expect(swaggerVersion).toEqual('3.0.0');
    });

    it('should return the openapi document if jmes query is empty', async () => {
      const result = await service.getOpenApiDocumentation(
        swagger2TestContent,
        '',
      );
      const swaggerVersion = result[openapi];
      expect(result).not.toEqual(swagger2TestContent);
      expect(swaggerVersion).toEqual('3.0.0');
    });

    it('should return the openapi document filtered with the jmes query', async () => {
      const result = await service.getOpenApiDocumentation(
        swagger2TestContent,
        'openapi',
      );
      expect(result).toEqual('3.0.0');
    });
  });
});
