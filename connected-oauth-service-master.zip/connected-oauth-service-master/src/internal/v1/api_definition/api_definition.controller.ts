import { ApiDefinitionService } from './api_definition.service';
import { Controller, Get, Headers, HttpException, Res } from '@nestjs/common';
import {
  ApiUseTags,
  ApiOperation,
  ApiResponse,
  ApiImplicitHeader,
} from '@nestjs/swagger';
import { HttpStatusCode } from '@bmw/http';

@ApiUseTags('API Definition')
@Controller('.internal/v1/api-definition')
export class ApiDefinitionController {
  constructor(private readonly apiDefinitionService: ApiDefinitionService) {}

  @ApiImplicitHeader({
    name: 'x-jmespath',
    description: 'JMESPath format query that will be applied to response',
  })
  @ApiOperation({ title: 'Returns the Open API documentation' })
  @ApiResponse({ status: 200, description: 'Success' })
  @ApiResponse({ status: 500, description: 'Internal Server Error' })
  @Get('openapi3')
  async getOpenApiDocumentation(
    @Headers('x-jmespath') jmesPathHeader: string,
    @Res() response,
  ): Promise<any> {
    try {
      const result = await this.apiDefinitionService.getOpenApiDocumentation(
        response.res.locals.swagger,
        jmesPathHeader,
      );
      response.send(result);
      return result;
    } catch (error) {
      throw new HttpException(
        'INTERNAL SERVER ERROR',
        HttpStatusCode.InternalServerError,
      );
    }
  }
}
