import { Test, TestingModule } from '@nestjs/testing';
import { StateController } from './state.controller';
import { HttpException } from '@nestjs/common';

describe('StateController', () => {
  let app: TestingModule;

  beforeAll(async () => {
    app = await Test.createTestingModule({
      controllers: [StateController],
    }).compile();
  });

  describe('/user/:usid (GET)', () => {
    it('should return throw HttpException User Not Found', async () => {
      const stateController = app.get<StateController>(StateController);
      try {
        await stateController.getUserState('usid');
        fail('should throw exception');
      } catch (error) {
        expect(error instanceof HttpException).toBe(true);
        expect((error as HttpException).getStatus()).toEqual(404);
        expect((error as HttpException).message).toEqual('USER NOT FOUND');
      }
    });
  });

  describe('/user/:usid (DELETE)', () => {
    it('should return throw HttpException User Not Found', async () => {
      const stateController = app.get<StateController>(StateController);
      try {
        await stateController.deleteUserState('usid');
        fail('should throw exception');
      } catch (error) {
        expect(error instanceof HttpException).toBe(true);
        expect((error as HttpException).getStatus()).toEqual(404);
        expect((error as HttpException).message).toEqual('USER NOT FOUND');
      }
    });
  });
});
