import { Module } from '@nestjs/common';

import { ApiDefinitionController } from './v1/api_definition/api_definition.controller';
import { HealthController } from './v1/health/health.controller';
import { StateController } from './v1/state/state.controller';
import { ApiDefinitionService } from './v1/api_definition/api_definition.service';

@Module({
  controllers: [ApiDefinitionController, HealthController, StateController],
  providers: [
    {
      provide: ApiDefinitionService,
      useValue: new ApiDefinitionService(),
    },
  ],
})
export class InternalModule {}
