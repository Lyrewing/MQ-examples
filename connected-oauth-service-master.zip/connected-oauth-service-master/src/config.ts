import * as dotenv from 'dotenv';
import * as path from 'path';

enum Environment {
  Local = 'local',
  NorthAmericaDaily = 'dly_na',
  NorthAmericaDevelopment = 'dev_na',
  NorthAmericaIntegration = 'int_na',
  NorthAmericaProduction = 'prod_na',
  RestOfWorldDaily = 'dly_eu',
  RestOfWorldDevelopment = 'dev_eu',
  RestOfWorldIntegration = 'int_eu',
  RestOfWorldProduction = 'prod_eu',
}

interface Config {
  gcdmBaseUrl: string;
  omcBaseUrl: string;
  port: number;
  loginBasicAuthToken: string;
  gatewayBasicAuthToken: string;
  localizationsDirectory: string;
  localizationsFilePattern: string;
  localizationsFallbackLanguage: string;
}

const currentEnv: Environment | string =
  process.env.CURRENT_ENV || Environment.Local;

if (currentEnv === Environment.Local) {
  dotenv.config();
}

export const config: Config = {
  gcdmBaseUrl: process.env.GCDM_BASE_URL,
  omcBaseUrl: process.env.OMC_BASE_URL,
  port: currentEnv === Environment.Local ? 8080 : 80,
  loginBasicAuthToken: process.env.LOGIN_BASIC_AUTH_TOKEN,
  gatewayBasicAuthToken: process.env.GATEWAY_BASIC_AUTH_TOKEN,
  localizationsDirectory: path.join(process.env.PWD, '/i18n'),
  localizationsFilePattern: '*.json',
  localizationsFallbackLanguage: 'en_US',
};
